""" package cco.schema
"""
